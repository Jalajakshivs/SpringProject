package com.rays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringStudentFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringStudentFormApplication.class, args);
	}

}

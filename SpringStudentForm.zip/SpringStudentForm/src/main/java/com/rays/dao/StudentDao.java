package com.rays.dao;


	
	import java.util.List;

	import org.springframework.stereotype.Service;

import com.rays.service.Student;

	@Service
	public interface  StudentDao {

		public void addStudent(Student student);
		public List<Student> getAllStudent();
		public Student getStudentById(int id);
		public void updateStudent(Student student);
		public void deleteStudent(int StudentId);
		public Student validateStudent(Student student);
	}




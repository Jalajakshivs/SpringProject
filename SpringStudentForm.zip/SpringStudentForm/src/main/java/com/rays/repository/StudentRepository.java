package com.rays.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import com.rays.service.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer>{
	

	@Query("select stu from Student stu where stu.studentName=(:studentName) and stu.studentPassword=(:studentPassword)")
	
	
	Student findByLoginData(String studentName, String studentPassword) ;
		
	
		
	}




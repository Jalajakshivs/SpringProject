package com.rays.service;

import java.util.Arrays;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.stereotype.Component;
	
	@Entity
	@Table(name = "Student")
	@Component
	public class Student  {

		@Id   //Specifies the primary key of an entity
		@GeneratedValue(strategy = GenerationType.AUTO)   // 
		private Integer id;
		//@Column(name = "Studentname")
		private String studentName;
		private String studentPassword;
		private Integer studentAge;
		private String studentCity;
		private String studentGender;
		private String studentDepartment;
		@Lob
		private byte[] studentPic;
		public Student () {
			super();
			// TODO Auto-generated constructor stub
		}
		public Student (Integer id, String studentName, String studentPassword, Integer studentAge, String studentCity) {
			super();
			this.id = id;
			this.studentName = studentName;
			this.studentPassword =studentPassword;
			this.studentAge = studentAge;
			this.studentCity = studentCity;
		}
		public Student (Integer id, String studentName, String studentPassword, Integer studentAge, String studentCity, byte[] studentPic) {
			super();
			this.id = id;
			this.studentName = studentName;
			this.studentPassword =studentPassword;
			this.studentAge = studentAge;
			this.studentCity = studentCity;
			this.studentPic = studentPic;
		}
		public Integer getId() {
			return id;
		}
		public void setId(Integer id) {
			this.id = id;
		}
		public String getStudentName() {
			return studentName;
		}
		public void setStudentName(String studentName) {
			this.studentName = studentName;
		}
		public String getStudentPassword() {
			return studentPassword;
		}
		public void setStudentPassword(String studentPassword) {
			this.studentPassword = studentPassword;
		}
		public Integer getStudentAge() {
			return studentAge;
		}
		public void setStudentAge(Integer studentAge) {
			this.studentAge = studentAge;
		}
		public String getStudentCity() {
			return studentCity;
		}
		public void setStudentCity(String studentCity) {
			this.studentCity = studentCity;
		}
		public byte[] getStudentPic() {
			return studentPic;
		}
		public void setStudentPic(byte[] studentPic) {
			this.studentPic = studentPic;
		}
			public String getStudentPicture() {
				return Base64.encodeBase64String(studentPic);
		}
			
			public String getStudentGender() {
				return studentGender;
			}
			public void setStudentGender(String studentGender) {
				this.studentGender = studentGender;
			}
			public String getStudentDepartment() {
				return studentDepartment;
			}
			public void setStudentDepartment(String studentDepartment) {
				this.studentDepartment = studentDepartment;
			}
			@Override
			public String toString() {
				return "Student [id=" + id + ", studentName=" + studentName + ", studentPassword=" + studentPassword
						+ ", studentAge=" + studentAge + ", studentCity=" + studentCity + ", studentGender="
						+ studentGender + ", studentDepartment=" + studentDepartment + ", studentPic="
						+ Arrays.toString(studentPic) + "]";
			}
			
			
			
		
		}
			